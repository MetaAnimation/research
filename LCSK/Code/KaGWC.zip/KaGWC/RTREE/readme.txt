Download from RtreePortal. 

SpatialIndex library